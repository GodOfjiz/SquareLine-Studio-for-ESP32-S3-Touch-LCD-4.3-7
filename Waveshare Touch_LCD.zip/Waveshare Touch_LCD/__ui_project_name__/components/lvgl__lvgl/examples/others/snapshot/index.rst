
Simple snapshot example
"""""""""""""""""""

.. lv_example:: others/snapshot/lv_example_snapshot_1
  :language: c


